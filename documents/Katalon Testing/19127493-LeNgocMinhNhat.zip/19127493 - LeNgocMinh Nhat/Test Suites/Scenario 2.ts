<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>28554b32-f9eb-49ea-9f06-1ed9aa0d298c</testSuiteGuid>
   <testCaseLink>
      <guid>c76db3d0-5c39-4b8e-97cf-347e53186538</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 2/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2251376f-583a-4cc2-9c64-6b8d1f238bc5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 2/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cc07ac14-ad1b-4470-98f0-15bf14cd7b92</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 2/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1e0562e3-409a-4012-ac49-35e1433da0d2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 2/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f247d39-f5b0-4545-995c-e54f69463ac7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 2/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
