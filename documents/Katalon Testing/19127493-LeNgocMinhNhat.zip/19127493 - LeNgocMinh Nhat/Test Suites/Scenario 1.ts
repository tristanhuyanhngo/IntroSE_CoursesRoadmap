<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>14c0f52b-92c3-4a95-b0b6-4b1428522683</testSuiteGuid>
   <testCaseLink>
      <guid>3f7b8917-a727-46be-915d-71cecf76f409</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 1/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d66f877a-17d9-46da-900c-3b413d6e13dd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 1/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>400aec79-bbb2-4657-953b-8923932c628e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 1/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cdbeea9c-66d0-4bcf-99f3-2c02d22586d9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 1/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d91fc80e-2fef-4415-9aa6-b75ab385d9db</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 1/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
