<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f3b0dce3-4a77-4759-9149-f2774566f8ec</testSuiteGuid>
   <testCaseLink>
      <guid>44633cc7-b8e9-400e-a6bc-449eee3ae9fe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 2/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8eb14f72-ca46-45f0-b323-b3dbec75f9f1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 2/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>294bf233-5e9b-4caf-a440-5f0584b9d675</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 2/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a2e521cb-568a-44c9-90fc-cc0f2bf88582</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 2/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f1008afe-47cd-4f7b-ba8f-a78f8dd8ab3c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 2/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
