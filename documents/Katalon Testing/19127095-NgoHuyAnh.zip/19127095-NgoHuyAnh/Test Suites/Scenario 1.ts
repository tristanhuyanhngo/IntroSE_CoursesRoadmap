<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>feccb33c-37d6-46a5-a1b9-94b18dd5ff7f</testSuiteGuid>
   <testCaseLink>
      <guid>9efd297d-dc1a-48e5-b2a1-47bc9a72bbbe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 1/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>15efb80d-e79e-49fb-81d6-a6e98084c5a5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 1/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3c18c3cf-ce81-4748-85c6-1d68d74e72ee</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 1/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8ed6a17b-5e9b-4124-bef9-f60e6fc4c415</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 1/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>dc5d599c-bcf4-4f37-b0f5-69060db39f1c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 1/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
