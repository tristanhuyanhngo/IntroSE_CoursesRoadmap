<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>89ac69c0-0065-4a4a-9121-0421f9947d80</testSuiteGuid>
   <testCaseLink>
      <guid>53f08fe7-4a85-4e3e-ae87-c19883523e34</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bfee2872-d9d8-4afa-b3a2-f6cf70e7c7c6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f2f92cd5-b249-4f08-bee5-5a7c2dcb11ba</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac75503e-b6df-4cd3-a9fe-19e980374b5a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>60f8441b-757d-4993-93cb-28286db95deb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
