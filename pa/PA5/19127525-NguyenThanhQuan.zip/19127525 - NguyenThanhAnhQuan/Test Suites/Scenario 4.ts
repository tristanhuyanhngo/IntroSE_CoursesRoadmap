<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 4</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>eff6b460-6880-4b6b-819b-e20fba5729a6</testSuiteGuid>
   <testCaseLink>
      <guid>82ed7eb3-f495-42c7-b007-81e4a9ac57a5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>161af570-0784-4b01-b01d-e501211ba934</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ea29c1bd-caa4-4988-81ac-1d057be7936c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>937fc512-4eaf-41a3-9805-2e268ad2edba</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3064061c-25e5-4f03-921d-9957de9e3c47</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
