<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 4</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3ba93614-8758-4eb9-b48f-033838762d1c</testSuiteGuid>
   <testCaseLink>
      <guid>2c06d5b8-1412-432b-8956-ec30df2d8f42</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5b054e46-05d0-4ef0-aaff-36f31f3e2ee4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3e5343ea-5f13-438e-abf8-aff37e7aa696</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ba7bbae0-2dc4-4dff-8e0f-2e10524065c3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e38697ff-13e8-4701-bef6-85042ac37567</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 4/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
