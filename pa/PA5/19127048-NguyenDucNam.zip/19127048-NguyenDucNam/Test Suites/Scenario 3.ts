<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scenario 3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4b65a14a-ca46-40fa-99b2-c9413d632e9a</testSuiteGuid>
   <testCaseLink>
      <guid>c930c4a3-90ec-44d4-9fbc-e4b9a15fc53f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>82db4431-bf38-4eed-8d58-10d87163c2cf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1e8ecd95-5895-4126-b71f-4a2d91279e0a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9923618e-0194-4676-8ba4-8c8f83dabbdd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9b14a861-0272-4cca-9677-2ceed0217f62</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
