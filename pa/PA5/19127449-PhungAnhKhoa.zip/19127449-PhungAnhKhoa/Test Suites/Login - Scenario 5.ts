<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login - Scenario 5</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c5dd614b-d425-4a39-98a6-9c2899a72fcb</testSuiteGuid>
   <testCaseLink>
      <guid>c342d8cf-6352-4f0b-8f39-76f37332e9a9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 5/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>50fa7bc4-e85b-40fd-a888-83a84cd37b5f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 5/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6db3a965-b8a3-45cb-b31f-a24acf9b63f5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 5/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8d0786e3-285d-42a3-84d3-0656cafc3be2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 5/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6fb13e05-bdec-4a9b-b398-25c0dc72c1d8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login/Scenario 5/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
