<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Register - Scenario 5</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6c09ff71-ec21-4301-9fcc-52316f9d3bf0</testSuiteGuid>
   <testCaseLink>
      <guid>ef092e02-dd7e-41ef-8c11-f058c1f7dc4b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 5/Test Case 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e9e92475-6976-44b5-b439-2b43d6089daa</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 5/Test Case 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8b3a9614-3109-40fe-a20d-643d9e3f4518</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 5/Test Case 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cf2ca90c-5fee-43c7-934c-ecacbd9bc275</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 5/Test Case 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5e3fa9d7-66ab-4fe1-a5ef-6fe8e8657735</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register/Scenario 5/Test Case 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
