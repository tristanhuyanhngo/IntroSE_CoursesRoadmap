import React from "react";

export default function EditButton(params) {
    return (
        <button type="button" className="btn btn-outline-dark btn-lg">Edit Profile</button>
    );
}