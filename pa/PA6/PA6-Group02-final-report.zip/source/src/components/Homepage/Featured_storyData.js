import React from 'react';

export const Featured_storyData = [
    {
        title: 'Kiến thức nhập môn',
        path: '/story',
        image: "/18.png",
        cName: 'course-item'
    },
    {
        title: 'Responsive Với Grid System',
        path: '/story',
        image: "/17.png",
        cName: 'course-item'
    },
    {
        title: 'Node & ExpressJS',
        path: '/story',
        image: "/15.png",
        cName: 'course-item'
    },
    {
        title: 'JavaScript Nâng Cao',
        path: '/story',
        image: "/14.png",
        cName: 'course-item'
    }
];
