import React from 'react';

export const CourseData = [
    {
        title: 'HTML, CSS từ Zero đến Hero',
        path: '/detailCourse',
        image: "/2.png",
        cName: 'course-item'
    },
    {
        title: 'JavaScript Cơ Bản',
        path: '/detailCourse',
        image: "/1.png",
        cName: 'course-item'
    },
    {
        title: 'Kiến thức nhập môn',
        path: '/detailCourse',
        image: "/5.png",
        cName: 'course-item'
    },
    {
        title: 'Responsive Với Grid System',
        path: '/detailCourse',
        image: "/3.png",
        cName: 'course-item'
    }
];
