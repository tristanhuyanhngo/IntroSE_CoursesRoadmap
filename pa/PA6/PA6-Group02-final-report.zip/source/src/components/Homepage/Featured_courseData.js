import React from 'react';

export const Featured_courseData = [
    {
        title: 'Kiến thức nhập môn',
        path: '/detailCourse',
        image: "/7.png",
        cName: 'course-item'
    },
    {
        title: 'Responsive Với Grid System',
        path: '/detailCourse',
        image: "/13.png",
        cName: 'course-item'
    },
    {
        title: 'Node & ExpressJS',
        path: '/detailCourse',
        image: "/6.png",
        cName: 'course-item'
    },
    {
        title: 'JavaScript Nâng Cao',
        path: '/detailCourse',
        image: "/12.png",
        cName: 'course-item'
    }
];
